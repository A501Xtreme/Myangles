class Main {
  public static void main(String[] args) {
    int myAge = 15;
    int myBirthday = March 21, 2005; 
    int todaysDate = September 27, 2020;
    System.out.println("I am " + myAge  + " years old ");
    System.out.println("My birthday is " + myBirthday);
    System.out.println("Todays date is " + todaysDate);
  }
}